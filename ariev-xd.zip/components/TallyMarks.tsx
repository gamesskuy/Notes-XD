
import React from 'react';

interface TallyMarksProps {
  count: number;
}

export const TallyMarks: React.FC<TallyMarksProps> = ({ count }) => {
  const fullGroups = Math.floor(count / 5);
  const remainder = count % 5;

  return (
    <div className="flex flex-wrap gap-2 sm:gap-3 items-center min-h-[24px]">
      {Array.from({ length: fullGroups }).map((_, i) => (
        <div key={`group-${i}`} className="relative flex mr-1.5 sm:mr-2">
          <div className="tally-mark"></div>
          <div className="tally-mark"></div>
          <div className="tally-mark"></div>
          <div className="tally-mark"></div>
          <div className="tally-slash"></div>
        </div>
      ))}
      <div className="flex">
        {Array.from({ length: remainder }).map((_, i) => (
          <div key={`remainder-${i}`} className="tally-mark"></div>
        ))}
      </div>
      {count === 0 && <span className="text-gray-500/40 italic text-[10px] sm:text-xs">Tap...</span>}
    </div>
  );
};
